import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
    /**
     * This class is for reading the height and width of the terrain and the number of obstacle from the var file.
     * @author Arzu Daban�yast�
     * @since 29.11.2020
     */
public class Config {
	public int height;
    public int width;
    int numberOfObstacle;
    /**
     * This method is constructor and this method calls readConfig method.
     */
    public Config() {
        readConfig();
    }
    /**
     * This method reads the variables from the var file.
     */
    public void readConfig() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/var.cfg"))) {
            String st = br.readLine();
            height = Integer.parseInt(st.split(" : ")[1]);
            st = br.readLine();
            width = Integer.parseInt(st.split(" : ")[1]);
            st = br.readLine();
            numberOfObstacle = Integer.parseInt(st.split(" : ")[1]);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Terrain.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Terrain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
