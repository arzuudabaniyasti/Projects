
/**
 * This class is for tile of terrain
 * @author Arzu Daban�yast�
 * @since 29.11.2020
 */
public class Tile {
	//all tile have a position
	Position position;
	//It indicates whether positions have been visited before on the map
    private boolean visited;
    /**
     * Constructor method
     */
    public Tile() {
    }
    /**
	 * This method returns position of tile
     * @return position - position value
     */
    public Position getPosition() {
		return position;
	}
    /**
     * set position of tile
     * @param position - position value
     */
	public void setPosition(Position position) {
		this.position = position;
	}
	/**
	 * This method returns visited value.
     * @return visited - boolean value
     */
	public boolean getVisited() {
		return visited;
	}
	/**
     * set visited value true or false
     * @param visited - boolean value
     */
	public void setVisited(boolean visited) {
		this.visited = visited;
	}
}
