    /**
     * This class is for locations on the map. It contains methods that can change location coordinates.
	 * @author Arzu Daban�yast�
	 * @since 29.11.2020
	 */
public class Position {
	private int i, j;
	/**
	 * Constructor method
     * @param i - value for x-axis
     * @param j - value for y-axis
     */
    public Position(int i, int j) {
        this.i = i;
        this.j = j;
    }
    /**
	 * returns the value of the position on the x-axis
     * @return i - int value for x-axis
     */
    public int getI() {
        return i;
    }
    /**
	 * returns the value of the position on the y-axis
     * @return j - int value for y-axis
     */
    public int getJ() {
        return j;
    }
    /**
     * Increases the i value of the position by 1
     */
    public void incI() {
        this.i++;
    }
    /**
     * Decreases the i value of the position by 1
     */
    public void decI() {
        this.i--;
    }
    /**
     * Increases the j value of the position by 1
     */
    public void incJ() {
        this.j++;
    }
    /**
     * Decreases the j value of the position by 1
     */
    public void decJ() {
        this.j--;
    }
    /**
     * This method compares this position with the position which is the parameter of the method, 
     * and returns true if they are the same.
     * @param k- int value for x-axis
     * @param l- int value for y-axis
     * @return isEqual - boolean value
     */
    public boolean equal(int k, int l) {
        boolean isEqual = false;
        if (i == k && j == l) {
            isEqual = true;
        }
        return isEqual;
    }
}
