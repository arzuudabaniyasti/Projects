import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class main {
    public static void main(String[] args) throws IOException {
		Config config=new Config();
        Terrain terrain=new Terrain(config);
        //create a terrain random
        terrain.createMap();
        //show the terrain
        terrain.showMap();
        //show the all posible route in which no tile is revisited for the player from starting point to finishing point .
        terrain.callRecursiveMethod();
	}
}
