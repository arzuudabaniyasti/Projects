import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
    /**
     * @author Arzu Daban�yast�
     * @since 29.11.2020
     */
public class Terrain {
	Config config;
	Tile[][]map;
	Position player;
	ArrayList<Position> obstacles;
	Position finishPoint;
	int counter=0;
	ArrayList<Position> correctPath;
	Random rand= new Random();
	/**
	 * @param config - It is a object for variables(height,width,numberOfObstacle)
	 */
	public Terrain(Config config) {
        this.config = config;
        obstacles=new ArrayList<>();
        correctPath=new ArrayList<>();
        map = new Tile[config.height][config.width];
    }
	/**
	 * This method create a new terrain
	 */
	public void createMap() {
    for (int k = 0; k < config.height; k++) {
        for (int l = 0; l < config.width; l++) {
            map[k][l] = new Tile();
        }
    }
    //create position for finish point
    int x = rand.nextInt(config.height - 1);
    int y = rand.nextInt(config.width - 1);
    finishPoint=new Position(x,y);
    //create all obstacles
    for (int k = 0; k < config.numberOfObstacle; k++) {
        Position position = generatePosition(obstacles, finishPoint);
        // (map[position.getI()][position.getJ()]).setObstacle(true);
        obstacles.add(new Position(position.getI(), position.getJ()));
    }
    //create position for player
    Position position = generatePosition(obstacles, finishPoint);
    player=new Position(position.getI(),position.getJ());
    }
	/**
	 * This method prints terrain
	 */
	public void showMap(){
	System.out.println("TERRAIN");
	for(int i = 0; i < map.length; i++){
        for(int j = 0; j < map[i].length; j++){
		    if(isPositionFromObstacle(i, j, obstacles)==true) {
		      	//obstacles
		        System.out.print("X"+" ");
		    }
		    else if(isPositionFromFinishPoint(i,j,finishPoint)==true) {
		      	//finish point
		      	System.out.print("F"+" ");
		    }
		    else if(player.getI()==i && player.getJ()==j) {
		      	System.out.print("p"+" ");
		    }
		    else {
		      	//Spaces
		      	System.out.print("O"+" ");
		    }
		}
		System.out.println(" ");
    }
	}
	/**
	 * This method calls recursiveMethod.
	 * This method controls all possible tiles to move and hide them
	 * @throws IOException - Constructs an IOException with null as its error detail message.
	 */
	public void callRecursiveMethod() throws IOException{
		System.out.println("-----All possible route-----");
		recursiveMethod(player.getI(),player.getJ());
		System.out.println("There are "+counter+" possible route");
	}
	/**
	 * This method is recursive method
	 * This method controls all possible route and prints them
	 * @param X- i value of the player's coordinate
	 * @param Y- j value of the player's coordinate
	 * @throws IOException - Constructs an IOException with null as its error detail message.
	 */
	public void recursiveMethod(int X,int Y) throws IOException {
    if (X == finishPoint.getI() && Y == finishPoint.getJ()){
        map[X][Y].setVisited(true);
    	correctPath.add(new Position(X,Y));
        mapCordinate();
        correctPath.remove(correctPath.size()-1);
    	map[X][Y].setVisited(false);
    	counter++;
    return;
    }
    if (X != 0) {
        if (!Terrain.isPositionFromObstacle(X - 1, Y, obstacles) && !map[X][Y].getVisited()==true) {
            map[X][Y].setVisited(true);
            correctPath.add(new Position(X,Y));
            recursiveMethod(X - 1, Y);
            correctPath.remove(correctPath.size()-1);
            map[X][Y].setVisited(false);
        }
    }
    if (X != config.height - 1) {
        if (!Terrain.isPositionFromObstacle(X + 1, Y, obstacles) && !map[X][Y].getVisited()==true) {
            map[X][Y].setVisited(true);
            correctPath.add(new Position(X,Y));
            recursiveMethod(X + 1, Y);
            correctPath.remove(correctPath.size()-1);
            map[X][Y].setVisited(false);
        }
    }
    if (Y != 0) {
        if (!Terrain.isPositionFromObstacle(X, Y - 1, obstacles)&& !map[X][Y].getVisited()==true ) {
            map[X][Y].setVisited(true);
            correctPath.add(new Position(X,Y));
            recursiveMethod(X , Y -1 );
            correctPath.remove(correctPath.size()-1);
            map[X][Y].setVisited(false);
        }
    }
    if (Y != config.width - 1) {
        if (!Terrain.isPositionFromObstacle(X, Y + 1, obstacles) && !map[X][Y].getVisited()==true) {
            map[X][Y].setVisited(true);
            correctPath.add(new Position(X,Y));
            recursiveMethod(X , Y+1);
            correctPath.remove(correctPath.size()-1);
            map[X][Y].setVisited(false);
        }
    }
    return;
    }
	/**
	 * This method prints the hided tiles for each route and prints to file
	 * @throws IOException - Constructs an IOException with null as its error detail message.
	 */
	public void mapCordinate() throws IOException  {
    File file = new File("output.txt");
    if (!file.exists()) {
        file.createNewFile();
    }
    FileWriter fileWriter = new FileWriter(file, true);
    BufferedWriter bWriter = new BufferedWriter(fileWriter);
    for(Position position:correctPath) {
        System.out.print("("+position.getI()+","+position.getJ()+")");
    	bWriter.write("("+position.getI()+","+position.getJ()+")");
    }
    System.out.println(" ");
    bWriter.newLine();
    bWriter.close();
    }
	/**
	 * This method controls whether there is an obstacle in the position taken as parameter, returns true if any
	 * @param i - int value of x-axis
	 * @param j - int value of y-axis
	 * @param obstacles - list of obstacle positions
	 * @return is - boolean value
	 */
    public static boolean isPositionFromObstacle(int i, int j, ArrayList<Position> obstacles) {
    boolean is = false;
        for (Position obs : obstacles) {
            if (i == obs.getI() && j == obs.getJ()) {
                is = true;
               break;
            }
    }
    return is;
    }
    /**
     * This method controls whether there is an finishPoint in the position taken as parameter, returns true if any
	 * @param i - int value of x-axis
	 * @param j - int value of y-axis 
	 * @param finishPoint - finishPoint position
	 * @return is - boolean value 
	 */
    public boolean isPositionFromFinishPoint(int i, int j, Position finishPoint) {
    boolean is = false;
        if (i == finishPoint.getI() && j == finishPoint.getJ()) {
            is = true;
    }
    return is;
    }
    /**
     * If there is no obstacle or finishPoint in the position assigned randomly, it returns this position.
	 * @param obstacles - list of obstacle positions
	 * @param finishPoint - finishPoint position
	 * @return position - new position without obstacles and finishPoint
	 */
    public Position generatePosition(ArrayList<Position> obstacles, Position finishPoint) {
    Random rand = new Random();
    int i = 0, j = 0;
        do {
            i = rand.nextInt(config.height-1);
            j = rand.nextInt(config.width-1);
        } while (isPositionFromObstacle(i, j, obstacles) || isPositionFromFinishPoint(i, j, finishPoint));
    return new Position(i, j);
    }
}   		