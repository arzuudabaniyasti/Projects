import java.io.IOException;

public class main {
    public static void main(String[]args) throws IOException  {
    	Config config=new Config();
        Terrain terrain=new Terrain(config);
        //Bir arazi olu�turur
        terrain.createMap();
        //Arazinin i�indeki oyuncular� haraket ettirerek yeni arazi durumunu ekrana yazd�r�r
        terrain.doMovement();
      
     }
}
