public class Position {
	/*
	 * @author:Arzu Daban�yast�
	 * @since:17.11.2020
	 */
    private int i, j;

    public Position(int i, int j) {
        this.i = i;
        this.j = j;
    }
    //getters
    public int getI() {
        return i;
    }
    public int getJ() {
        return j;
    }
    //increase or decrease I
    public void incI() {
        this.i++;
    }
    public void decI() {
        this.i--;
    }
    //increase or decrease J
    public void incJ() {
        this.j++;
    }
    public void decJ() {
        this.j--;
    }
    //check if positions are equal 
    public boolean equal(int k, int l) {
        boolean isEqual = false;
        if (i == k && j == l) {
            isEqual = true;
        }
        return isEqual;
    }
}
