import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.util.Random;
import java.util.Scanner;

public class Terrain {
	/*
	 * @author:Arzu Daban�yast�
	 * @since:17.11.2020
	 */
	Config config;
    Tile[][] map;
    Position finishPoint;
    Player[] players;
    Position[] obstacles;
    Position[] currentPlayers;
    Random rand= new Random();
    Scanner scanner=new Scanner(System.in);
    
    public Terrain(Config config) {
        this.config = config;
        players=new Player[config.numberOfPeople];
        obstacles=new Position[config.numberOfObstacle];
        currentPlayers=new Position[config.numberOfPeople];
        map = new Tile[config.height][config.width];
    }
    
    public void createMap() {
        for (int k = 0; k < config.height; k++) {
            for (int l = 0; l < config.width; l++) {
                map[k][l] = new Tile(new Position(k, l));
            }
        }
        //create finish point
        int x = rand.nextInt(config.height - 1);
        int y = rand.nextInt(config.width - 1);
        finishPoint=new Position(x,y);
        //obstacle arrayini olu�tur
        for(int k=0;k<config.numberOfObstacle;k++)
        	obstacles[k]=new Position(finishPoint.getI(),finishPoint.getJ());
        //Obstacle pozisyonlar�n� olu�tur ve yerle�tir
        for (int k = 0; k < config.numberOfObstacle; k++) {
        	Position position = generatePosition(config.height - 1, config.width - 1,obstacles, finishPoint);
            obstacles[k]=new Position(position.getI(), position.getJ());
        }
        //Player pozisyonlar�n� tutan arrayi olu�tur
        for(int k=0;k<config.numberOfPeople;k++)
        	currentPlayers[k]=new Position(finishPoint.getI(),finishPoint.getJ());
        //player arrayini olu�tur
        for(int k=0;k<config.numberOfPeople;k++)
        	players[k]=new Player(new Position(finishPoint.getI(),finishPoint.getJ()),k);
        //Player nesnelerini olu�tur ve yerle�tir
        for (int k = 0; k < config.numberOfPeople; k++) {
            Position position = generatePosition(config.height - 1, config.width - 1, obstacles, finishPoint);
            (map[position.getI()][position.getJ()]).setPlayer(true);
            Player p = new Player(position,k+1);
            players[k]=new Player(new Position(position.getI(), position.getJ()),p.getId());
            currentPlayers[p.getId()-1]=p.getPosition();
        }
    }
   
   
    public void doMovement()throws IOException {
    	File file = new File("output_final.txt");
            if (!file.exists()) {
                file.createNewFile();
            }
        FileWriter fileWriter = new FileWriter(file, false);
        BufferedWriter bWriter = new BufferedWriter(fileWriter);
    	int a=0;
    	boolean GameOver=false;
    	System.out.println("Game is starting");
    	System.out.println("Oyunun tamam�n� g�rmek i�in 2ye ad�m ad�m izlemek i�in her ad�mdan �nce 1e bas�n�z");
    	int option=scanner.nextInt();
    	System.out.println("The first status of the terrain");
    	if(option==1) {
    	while(!GameOver){ 
    		updateTile();
        	showMap();
        	option=scanner.nextInt();
        	a++;
        	System.out.println(a+". Turn");
    	    for(Player p: players) {
                p.move(config.height, config.width, obstacles);
                if(p.getPosition().equal(finishPoint.getI(),finishPoint.getJ())) {
                    updateTile();
            	    showMap();
                    System.out.println(" Game is over");
                    bWriter.write("Game is over");
                    bWriter.newLine();
                    System.out.println(p.getId()+". oyuncu kazand�");
                    bWriter.write(p.getId()+". oyuncu kazand�");
                    bWriter.close();
                    GameOver=true; 
            	    break; 
                }
            }
        }
        }	
        else if(option==2) {
        while(!GameOver){ 
            updateTile();
            showMap();
            a++;
            System.out.println(a+". Turn");
        	for(Player p: players) {
                p.move(config.height, config.width, obstacles);
                if(p.getPosition().equal(finishPoint.getI(),finishPoint.getJ())) {
                	 updateTile();
                	 showMap();
                     System.out.println(" Game is over");
                     bWriter.write("Game is over");
                     bWriter.newLine();
                     System.out.println(p.getId()+". oyuncu kazand�");
                     bWriter.write(p.getId()+". oyuncu kazand�");
                     bWriter.close();
                     GameOver=true; 
                	 break; 
                 }
             }
         }
         }
    } 
    /*record the status of the terrain for each turn so that 
    you can show the whole game step by step.*/
    public void updateTile() {
   	for (int k = 0; k < config.height; k++) {
        for (int l = 0; l < config.width; l++) {
        (map[k][l]).clear();
            if (!isPositionFromObstacle(k,l,obstacles)) {
                for (Player p : players) {
                    if (p.getPosition().equal(k, l)) {
                        (map[k][l]).setPlayer(true);  
                        currentPlayers[p.getId()-1]=p.getPosition();
                       }
                   }
               }
           }
    }
    }
    int sayi=0;
    public void showMap() throws IOException{
    	File file = new File("output_"+sayi+".txt");
        if (!file.exists()) {
            file.createNewFile();
        }
        FileWriter fileWriter = new FileWriter(file, false);
        BufferedWriter bWriter = new BufferedWriter(fileWriter);
        bWriter.write(sayi+". Turn");
        bWriter.newLine();
        ++sayi;
    for(int i = 0; i < map.length; i++){
        for(int j = 0; j < map[i].length; j++){
            if(isPositionFromObstacle(i, j, obstacles)==true) {
      	    	//obstacles
        	    System.out.print("X"+" ");
      	        bWriter.write("X"+" ");
      	    }
      	    else if(isPositionFromFinishPoint(i,j,finishPoint)==true) {
      	    	//finish point
      	    	System.out.print("F"+" ");
      	    	bWriter.write("F"+" ");
      	    }
      	    else if(map[i][j].isPlayer()==true) {
      	    	int a=0;
      	    	for(int s=0;s<currentPlayers.length;s++) {
      	            if(currentPlayers[s].getI()==i && currentPlayers[s].getJ()==j) {
      	        		a++;
      	        	}
      	        }
      	        if(a>1) {
    	        	//multiple players
    	    		System.out.print(a+" ");
    	    		bWriter.write(a+" ");
    	    	}
    	    	else {
    	    		//players
    	    		System.out.print("p"+" ");
    	    		bWriter.write("p"+" ");
    	    	}
      	    }
      	    else {
      	    	//Spaces
      	    	System.out.print("O"+" ");
      	        bWriter.write("O"+" ");
      	    }
        }
        System.out.println(" ");
        bWriter.newLine();
       
    }
    bWriter.close();
    }
    //Verilen pozisyonda obstacle olup olmad���n� kontrol eder
    public static boolean isPositionFromObstacle(int i, int j,Position[] obstacles) {
    boolean is = false;
        for (Position obs : obstacles) {
            if (i == obs.getI() && j == obs.getJ()) {
                is = true;
               break;
            }
    }
    return is;
    }
    //Verilen pozisyonda biti� noktas� olup olmad���n� kontrol eder
    public static boolean isPositionFromFinishPoint(int i, int j, Position finishPoint) {
    boolean is = false;
        if (i == finishPoint.getI() && j == finishPoint.getJ()) {
            is = true;
    }
    return is;
    }
    //Verilen pozisyonda obstacle ya da biti� noktas� yoksa o pozisyonu return eder
    public static Position generatePosition(int height, int width, Position[] obstacles, Position finishPoint) {
    Random rand = new Random();
    int i = 0, j = 0;
        do {
            i = rand.nextInt(height);
            j = rand.nextInt(width);
        } while (isPositionFromObstacle(i, j, obstacles) || isPositionFromFinishPoint(i, j, finishPoint));
    return new Position(i, j);
}
}