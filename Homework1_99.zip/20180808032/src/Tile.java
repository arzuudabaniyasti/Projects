public class Tile {
	/*
	 * @author:Arzu Daban�yast�
	 * @since:17.11.2020
	 */
	Position position;
    private boolean player;
    public Tile(Position position) {
        this.position = position;
    }
    public void setPlayer(boolean player) {
        this.player = player;
    }
    public boolean isPlayer() {
        return player;
    }
    public void clear() {
        player=false;
    }
}
