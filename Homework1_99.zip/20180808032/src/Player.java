import java.util.Random;
public class Player{
	/*
	 * @author:Arzu Daban�yast�
	 * @since:17.11.2020
	 */
    private Position position;
    //Her oyuncu bir ID'ye sahiptir
    private int id;
    public Player(Position position,int id) {
        this.position = position;
        this.id=id;
    }
    //getter
    public Position getPosition() {
	    return position;
	}
    //setter
    public void setPosition(Position position) {
	    this.position = position;
	}
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	//All players must make a random movement for each turn.All movements must be in random direction (north, south, east or west).
    public void move(int height, int width,Position[] obstacles) {
	    Random rand = new Random();
	    boolean ok = true;
	    int choice = rand.nextInt(4);
	    switch (choice) {
	        case 0://north
	            if (position.getI() != 0) {
	                if (!Terrain.isPositionFromObstacle(position.getI() - 1, position.getJ(), obstacles)) {
	                    position.decI();
	                }
	            }
	        break;
	        case 1://south
	            if (position.getI() != height - 1) {
	                if (!Terrain.isPositionFromObstacle(position.getI() + 1, position.getJ(), obstacles)) {
	                     position.incI();
	                }
	            }
	        break;
	        case 2://east
	            if (position.getJ() != 0) {
	                if (!Terrain.isPositionFromObstacle(position.getI(), position.getJ() - 1, obstacles)) {
	                    position.decJ();
	                }
	            }
	        break;
	        case 3://west
	            if (position.getJ() != width - 1) {
	                if (!Terrain.isPositionFromObstacle(position.getI(), position.getJ() + 1, obstacles)) {
	                    position.incJ();
	                }
	            }
	        break;
	    }
	}
}
