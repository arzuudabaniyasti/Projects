
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Config {
	/*
	 * @author:Arzu Daban�yast�
	 * @since:17.11.2020
	 */
    public int height;
    public int width;
    int numberOfPeople;
    int numberOfObstacle;
    public Config() {
        readConfig();
    }
    public void readConfig() {
        try (BufferedReader br = new BufferedReader(new FileReader("src/var.cfg"))) {
            String st = br.readLine();
            height = Integer.parseInt(st.split(" : ")[1]);
            st = br.readLine();
            width = Integer.parseInt(st.split(" : ")[1]);
            st = br.readLine();
            numberOfPeople = Integer.parseInt(st.split(" : ")[1]);
            st = br.readLine();
            numberOfObstacle = Integer.parseInt(st.split(" : ")[1]);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Terrain.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Terrain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
